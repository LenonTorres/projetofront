<?php

session_start();
require_once('./config.php');
$sql = "select * from log";
$sql_log= $conexao ->query($sql);
$numerosdelinhas=$sql_log ->num_rows;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="vizu.css">
</head>
<body>
  

<header>
    <nav class="navbar navbar-expand-lg navbar-light ">
      <div class="container-fluid">
        <a class="navbar-brand d-lg-none" href="index.html">
          <img src="./imagem/teleal.png" alt="" width="180" height="45"
            class="d-inline-block align-text-top">
        </a>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav mx-auto">
         

            <a class="navbar-brand d-none d-lg-block" href="#">
              <img src="./imagem/teleal.png" alt="" width="170" height="40"
                class="d-inline-block align-text-top">
            </a>

            
            
           
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <br><br><br>

<div class="container-fluid"> 
       <div class="table-responsive"> 
        <table class="table align-middle  text-white table-bg">
            <thead>
                <tr>
                  
                    <th>Id</th>
                    <th>Id do Usuario</th>
                    <th>Método de Login</th>
                    <th>Data do Login</th>
                    <th>Status do Login</th>
                </tr>
            </thead>
            <tbody> 
            <?php if ($numerosdelinhas == 0) {  ?>
                <tr>
                    <td colspan="5">Nenhhum Usuário Foi Cadastrado</td>
                </tr>
                <?php } else {
                
                
                while ($log = $sql_log->fetch_assoc()) { ?>
                    <tr>
                    
                        <td><?php echo $log['Id_log'] ?></td>
                        <td><?php echo $log['usuario_id'] ?></td>
                        <td><?php echo $log['log_method'] ?></td>
                        <td><?php echo $log['log_data'] ?></td>
                        <td><?php echo $log['log_status'] ?></td>
                    </tr>
            <?php }
            } ?>
            </tbody>    
            
            </div>
            </div>
        </table>    
        </div>            


        <div class="d-grid gap-2 col-6 mx-auto">
  <a class="btn btn-primary" href="sistema.php">Area do Administrador</a>
  <a class="btn btn-primary" href="./doc.html">MEU DOC</a>
  <a  class="btn btn-primary" href="./sistema.php">Voltar</a>
</div>
              
</body>
</html>