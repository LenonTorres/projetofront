<?php
if(isset($_POST['submit']))     //Se existir a variavel submit,ele salva as informações inseridas
  {
      include_once('config.php'); //Incluindo minha conexão
    
    //Passando meus parametros para as variaveis
    $nome = $_POST["nome"];
    $data_nascimento = $_POST["data_nascimento"];
    $sexo = $_POST["sexo"];
    $nome_materno = $_POST["nome_materno"];
    $cpf = $_POST["cpf"];
    $telefone_celular = $_POST["telefone_celular"];
    $telefone_fixo = $_POST["telefone_fixo"];
    $endereco = $_POST["endereco"];
    $login = $_POST["email"];
    $senha = $_POST["senha"];
    $confirmar_senha = $_POST["confirmar_senha"];

      $result = mysqli_query($conexao, "INSERT INTO usuarios(cpf,nome,data_nascimento,sexo,nomematerno,telefonecelular,telefonefixo,endereco,email,senha,tipo) 
      VALUES ('$cpf','$nome','$data_nascimento','$sexo','$nomematerno','$telefonecelular','$telefonefixo','$endereco','$email','$senha', 0)");//Criando minha variavel de conexao , Passando o INSERT pra os devidos campos
  }
?>  

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="./formulario.css">
    <title>Ambiente do Cliente</title>
  </head>
  <body>

 <!--Acessbilidade-->

      
  <div class="px-4 py-5 my-5 text-center">
    <img class="d-block mx-auto mb-4" src="./imagem/sólogo.png" alt=""  height="70">
    <h1 class="display-5 fw-bold text-white">Telecall</h1>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4 text-white">Conectando você ao mundo</p>
    </div>
  </div>
  

    <div class="container-fluid">
    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
          <form action="testLogin.php" method="POST" class="sign-in-form">
            <h2 class="title">Telecall é a sua solução</h2>
            <div class="input-field">
            <i class="bi bi-person-video2"></i>
              <input type="email" placeholder="Insira seu email" name="email" />
            </div>
            <div class="input-field">
            <i class="bi bi-shield-lock-fill"></i>
              <input type="password" placeholder="Insira sua senha" name="senha" />
            </div>
            <input type="submit" value="Login" class="btn solid" name="submit" />
            
          </form>
          <form action="index.php" method="POST" class="sign-up-form">
         

            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-person-circle"></i>
              <input type="cpf" placeholder="Insira seu CPF" name="cpf" maxlength="11"
                  onkeypress='return onlynumber();'>
                  <span id="cpf-error"></span>
            </div>
            </div>
           
             
          
            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-person-rolodex"></i>
              <input type="text" placeholder="Insira seu Nome e Sobrenome" name="nome"   id="contact-name" onkeyup="validateName()">
              <span id="name-error"></span>
            </div>
            </div>
            
            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-person-rolodex"></i>
              <input type="text" placeholder="Insira sua data de nascimento" name="dtnascimento"   id="contact-name">
              <span id="name-error"></span>
            </div>
            </div>

            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-people-fill"></i>
              <input type="text" placeholder="Insira seu Sexo" name="sexo" 
              id="contact-name2">
              <span id="name-error"></span>
            </div>
            </div>

            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-people-fill"></i>
              <input type="text" placeholder="Insira seu nome Materno" name="nomematerno" 
              id="contact-name2" onkeyup="validateName2()">
              <span id="name-error"></span>
            </div>
            </div>
            
           


            <div class="input-formas">
             <div class="input-field">
             <i class="bi bi-phone-fill"></i>
              <input type="tel"  name="telefonecelular" placeholder=" Telefone Celular " id="contact-phone" onkeyup="validatePhone()">
              <span id="phone-error"></span>
            </div>
            </div>
            


            
            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-telephone-outbound-fill"></i>
              <input type="tel"  name="telefonefixo"  placeholder="Telefone Fixo"  id="contact-phone2" onkeyup="validatePhone2()">
              <span id="pho"> </span>
            </div>
            </div>
           


            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-house-fill"></i>
              <input type="text" placeholder="Insira seu Endereço"  name="endereco" id="contact-message" onkeyup="validateMessage()" />
              <span id="message-error"></span>
            </div>
            </div>
           

            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-person-video2"></i>
              <input type="email"  name="email" placeholder="Insira seu email"  id="contact-email" onkeyup="validateEmail()" >
              
            </div>
            </div>
            



            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-shield-lock-fill"></i>
              <input type="password" placeholder="Crie uma senha" name="senha" id="idSenha" onblur="return QTDsenha()">
          
            </div>
            </div>

            <div class="input-formas">
            <div class="input-field">
            <i class="bi bi-shield-lock-fill"></i>
              <input type="password" placeholder="Confirme sua senha" name="senha" id="idconfSenha" onblur="return QTDsenha()">
          
            </div>
            </div>
            <input type="submit" value="Login" class="btn solid" name="submit" > 
          </form>
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            <h3>Faça parte do grupo de Clientes Telecall</h3>
            <button class="btn transparent" id="sign-up-btn">
             Se-Inscreva
            </button>
          </div>
          <img src="../sistema-cadastro-php-main/imagem/imagem1.svg" class="image" alt="" />
        </div>
        <div class="panel right-panel">
          <div class="content">
            <h3>Já é cadastrado  ?</h3>
            <p>
               Fique por dentro de todas nossas promoções e eventos. <br> <br>
               Há 17 anos servindo com maestria.
            </p>
            <button class="btn transparent" id="sign-in-btn">
              Entrar
            </button>
          </div>
          <img src="../sistema-cadastro-php-main/imagem/imagem2.svg" class="image" alt="" />
        </div>
      </div>
    </div>
  </div>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <footer>

<div class="waves">
  <div class="wave" id="wave1"></div>
  <div class="wave" id="wave2"></div>
  <div class="wave" id="wave3"></div>
  <div class="wave" id="wave4"></div>
</div>
<ul class="social-icon">
   <li><a href="https://www.facebook.com/TelecallBr"><ion-icon name="logo-facebook"></ion-icon></a></li>
   <li><a href="https://www.instagram.com/telecallbr/"><ion-icon name="logo-instagram"></ion-icon></a></li>
   <li><a href="https://www.linkedin.com/company/telecall/"><ion-icon name="logo-linkedin"></ion-icon></a></li>
</ul>

<p>@2023 Lenon Torres |Telecall Project </p>
</footer>
  
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>
    
    <script> src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"</script>

    <script src="app.js"></script>
    <script src="./formulario.js"></script>
    
   
   
  </body>
</html>
