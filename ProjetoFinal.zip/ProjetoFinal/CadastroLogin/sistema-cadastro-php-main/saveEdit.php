<?php
    // isset -> serve para saber se uma variável está definida
    include_once('config.php');
    if(isset($_POST['update']))
    {   
        
        $id = $_POST['id'];
        $tipo = $_POST['tipo'];
        $cpf = $_POST['cpf'];
        $nome = $_POST['nome'];
        $nomematerno = $_POST['nomematerno'];
        $telefonecelular = $_POST['telefonecelular'];
        $telefonefixo = $_POST['telefonefixo'];
        $endereco = $_POST['endereco'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
       
        
        $sqlInsert = "UPDATE usuarios 
        SET cpf='$cpf',nome='$nome',nomematerno='$nomematerno',telefonecelular='$telefonecelular',telefonefixo='$telefonefixo',endereco='$endereco',email='$email',senha='$senha'
        WHERE id=$id";
        $result = $conexao->query($sqlInsert);
        print_r($result);
    }
    header('Location: sistema.php');

?>