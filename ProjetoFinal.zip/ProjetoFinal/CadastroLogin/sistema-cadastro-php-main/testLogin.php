<?php
    session_start();
    
    if(isset($_POST['submit']) && !empty($_POST['email']) && !empty($_POST['senha']))
    {
        // Acessa
        include_once('config.php');
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        $sql = "SELECT * FROM usuarios WHERE email = '$email' and senha = '$senha'";

        $result = $conexao->query($sql);


        if(mysqli_num_rows($result) < 1)
        {
            unset($_SESSION['email']);
            unset($_SESSION['senha']);
           
            header('Location: ./index.php');
            echo "Login inválido";
        }
        else 
        {     
            $user=mysqli_fetch_array($result);
            session_start();
            $_SESSION['cpf']=$user['cpf'];
            $_SESSION['nome']=$user['nome'];
            $_SESSION['sexo']=$user['sexo'];
            $_SESSION['data_nascimento']=$user['data_nascimento'];
            $_SESSION['nomematerno']=$user['nomematerno'];
            $_SESSION['telefonecelular']=$user['telefonecelular'];
            $_SESSION['telefonefixo']=$user['telefonefixo'];
            $_SESSION['endereco']=$user['endereco'];
            $_SESSION['email']=$user['email'];
            $_SESSION['senha']=$user['senha'];

            Var_dump( $_SESSION['tipo']);

          
            header('Location: ./home.html');
        }
    }
    else
    {
        // Não acessa
        header('Location: login.php');
    }
?>