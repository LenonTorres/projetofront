var nameError=document.getElementById('name-error');
var name2Error=document.getElementById('name2-error');
var messageError=document.getElementById('message-error');
var phoneError=document.getElementById('phone-error');
var phone2Error=document.getElementById('phone2-error');
var emailError=document.getElementById('email-error');
var cpfError=document.getElementById('cpf-error');
var senhaError=document.getElementById('senha-error');










function onlynumber(evt) {
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode( key );
    //var regex = /^[0-9.,]+$/;
    var regex = /^[0-9.]+$/;
    if( !regex.test(key) ) {
       if(theEvent.preventDefault) theEvent.preventDefault();
       
       

    }    
    cpfError.innerHTML='<i class="bi bi-check-circle-fill"></i>';
    return true;


}

 

function validateName(){

   var name = document.getElementById('contact-name').value;

   if (name.length == 0){
       nameError.innerHTML='Coloque até dois nomes';
       return false;
   }

   if (!name.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/)){
       nameError.innerHTML='É necessário colocar Nome e Sobrenome';
       return false;
   }

   nameError.innerHTML='<i class="bi bi-check-circle-fill"></i>';
   return true;
}



 



 


 

function validatePhone(){

    var phone = document.getElementById('contact-phone').value;
    

    if(phone.length == 0){
        phoneError.innerHTML = 'Insira um numero  válido ';
        return false;
    }

    if (phone.length !== 11){
        phoneError.innerHTML = 'Insira seu DDD + Numero';
        return false;
    }

    if(!phone.match(/^[0-9]{11}$/)){

        phoneError.innerHTML='Insira um numero  valido';
        return false
    }

    phoneError.innerHTML= '<i class="bi bi-check-circle-fill"></i>';
    return true
}




function validatePhone2(){

    var phone2 = document.getElementById('contact-phone2').value;

    if(phone.length == 0){
        phone2Error.innerHTML = 'Insira um numero  válido ';
        return false;
    }

    if (phone2.length !== 11){
        phone2Error.innerHTML = 'Insira seu DDD + Numero';
        return false;
    }

    if(!phone2.match(/^[0-9]{11}$/)){

        phone2Error.innerHTML='Insira um numero  valido';
        return false
    }

    phone2Error.innerHTML= '<i class="bi bi-check-circle-fill"></i>';
    return true
}



function validateMessage(){
    var message = document.getElementById('contact-message').value;
    var required = 25;
    var left = required - message.length;

    if (left > 0){
        messageError.innerHTML = left + 'Diga sua Localização';
        return false;
    }

    messageError.innerHTML='<i class="bi bi-check-circle-fill"></i>';
    return true;
}


function validateEmail(){
  var email=document.getElementById('contact-email').value;

  if(email.length ==0){ /* Vou receber o valor da caixa de mensagem,se não tiver preenchido,irei retorna uma mensagem solicitando que o cliente insira o email,negando a validação com a caixa vazia*/
      emailError.innerHTML='Insira seu email' /*Menor que zero,retorna false,com uma mensagem */
      return false;
  }

  if(!email.match(/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/)){ /* Nessa variavel quer dizer que aceita qualquer alfabeto,e também aceita alguns pontos,ifens,traços,entre outros códigos*/
      emailError.innerHTML='Email invalido'
      return false


  }


  emailError.innerHTML='<i class="bi bi-check-circle-fill"></i>';
  return true
}










function QTDsenha(){
    var senha = document.getElementById('idSenha');
      if(senha.value.length < 6){
        senhaError.innerHTML='Aumente a segurança da sua senha';
          return false;
      }   senhaError.innerHTML='<i class="bi bi-check-circle-fill"></i>';
      return true;
  }